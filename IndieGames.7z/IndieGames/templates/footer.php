<footer class="container-fluid text-center">
  <p>IndieGames Copyright© 2017 </p>  
</footer>
</body>
</html>