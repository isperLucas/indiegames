<?php
include "templates/topoL.php";
?>
								<!-- LADO ESQUERDO -->
<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3 well">
      <div class="well">
        <p><a href="#">Meu perfil</p>
        <img src="img\avatarexemplo.png" class="img-circle" height="65" width="65" alt="Avatar">
      </div>
      <div class="well">
        <p><a href="#">Biografia</a></p>
        <p>
          Criador de jogos independentes desde 2012
        </p>
      </div>
      <div class="alert alert-success fade in">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <p><strong>Você tem novas notificações</strong></p>
        
      </div>
      <p><a href="#">Adicione um link</a></p>
      <p><a href="#">Adicione um link</a></p>
      <p><a href="#">Adicione um link</a></p>
	  
	  <br>
	  
	  
	  <a href="#"><div class="well col-sm-6">
         <p>Seguindo</p>
		<p><strong>67</strong></p>
      </div></a>
      <a href="#"><div class="well col-sm-6">
        <p>Seguidores</p>
		<p><strong>51</strong></p>
      </div></a>
	  
    </div>
	
	
	
	
				<!-- MEIO -->
    <div class="col-sm-6">
    
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default text-left">
            <div class="panel-body">
             <div class="form-group">
		<label for="comment">Publique algo:</label>
			<textarea class="form-control" rows="5" id="comment"></textarea>
				</div>
                
				<button type="button" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-new-window"></span> Publicar
              </button>
            </div>
          </div>
        </div>
      </div>
      
     <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-body">
        <a href="#"><div class="col-sm-3">
          <div class="well">
           <p>Jonas</p>
           <img src="img/avatarexemplo.png" class="img-circle" height="55" width="55" alt="Avatar">
         </div>
         </a></div>
        <div class="col-sm-9">
          <div class="well">
            <p>Doom entrou no túnel do tempo para pousar diretamente em 2016. Um dos games de tiro mais famosos do mundo está de volta nos títulos da geração atual, e você já pode experimentar essa novidade diretamente no seu computador.</p>
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  
	  
	  
	   <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-body">
        <a href="#"><div class="col-sm-3">
          <div class="well">
           <p>Jonas</p>
           <img src="img/avatarexemplo.png" class="img-circle" height="55" width="55" alt="Avatar">
         </div>
         </a></div>
        <div class="col-sm-9">
          <div class="well">
            <p>Doom entrou no túnel do tempo para pousar diretamente em 2016. Um dos games de tiro mais famosos do mundo está de volta nos títulos da geração atual, e você já pode experimentar essa novidade diretamente no seu computador.</p>
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  
	  
 <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-body">
        <a href="#"><div class="col-sm-3">
          <div class="well">
           <p>Jonas</p>
           <img src="img/avatarexemplo.png" class="img-circle" height="55" width="55" alt="Avatar">
         </div>
         </a></div>
        <div class="col-sm-9">
          <div class="well">
            <p>Doom entrou no túnel do tempo para pousar diretamente em 2016. Um dos games de tiro mais famosos do mundo está de volta nos títulos da geração atual, e você já pode experimentar essa novidade diretamente no seu computador.</p>
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  
	  
	   <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-body">
        <a href="#"><div class="col-sm-3">
          <div class="well">
           <p>Jonas</p>
           <img src="img/avatarexemplo.png" class="img-circle" height="55" width="55" alt="Avatar">
         </div>
         </a></div>
        <div class="col-sm-9">
          <div class="well">
            <p>Doom entrou no túnel do tempo para pousar diretamente em 2016. Um dos games de tiro mais famosos do mundo está de volta nos títulos da geração atual, e você já pode experimentar essa novidade diretamente no seu computador.</p>
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  
	   <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-body">
        <a href="#"><div class="col-sm-3">
          <div class="well">
           <p>Jonas</p>
           <img src="img/avatarexemplo.png" class="img-circle" height="55" width="55" alt="Avatar">
         </div>
         </a></div>
        <div class="col-sm-9">
          <div class="well">
            <p>Doom entrou no túnel do tempo para pousar diretamente em 2016. Um dos games de tiro mais famosos do mundo está de volta nos títulos da geração atual, e você já pode experimentar essa novidade diretamente no seu computador.</p>
			
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  

	 
	  
	  
    
    </div>
	
	<!-- LADO DIREITO -->
    <div class="col-sm-3 well">
      <div class="thumbnail">
        <p>Recomendado</p>
        <img src="img/jogo2.png"  width="400" height="300">
        <p><strong>Mega Malarque</strong></p>
        <p>20 mar. 2017</p>
        <button class="btn btn-primary">Descrição</button>
      </div>      
	  <br>
	  <p><h4>Recomendados</h4></p>
      <a href="#"><div class="well col-sm-6">
         <p>AnaGames</p>
		<p><img src="img/avatarexemplo2.png" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
      <a href="#"><div class="well col-sm-6">
        <p>Rafael_java</p>
		<p><img src="img/avatarexemplo3.png" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
	  
	  <a href="#"><div class="well col-sm-6">
         <p>SophiaGamer</p>
		<p><img src="img/avatarexemplo4.png" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
      <a href="#"><div class="well col-sm-6">
        <p>AnaGames</p>
		<p><img src="img/avatarexemplo2.png" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
	  
    </div>
  </div>
</div>

<?php
include "templates/footer.php";
?>
