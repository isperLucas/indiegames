<footer class="container-fluid text-center">
<img  src="img/logov4.png"  height="36px">

  <p>Indie Games Copyright © 2017</p>
  
</footer>

</body>
</html>