<?php
    session_start();
    include_once "classes/conexao.class.php";
    include_once "classes/zipar.class.php";
    $con = new Conexao();
    $zip = new Zipar();

  
    try{
            $usuario_id = $_SESSION['id'];
            $nome = $_POST['nomejg'];
            $desc = $_POST['descJg'];
            $ctgJg = $_POST['ctgJg'];
            $data_public = date('d/m/Y');
        
            $con = $con->conectar();
            $cst = $con->prepare("INSERT INTO `arquivos` (usuario_id, nome, data_public, descricao, categoria) VALUES (:usuario_id, :nome, :data_public, :desc, :ctgJg);");
            $cst->bindParam(":usuario_id", $usuario_id);
            $cst->bindParam(":nome", $nome);
            $cst->bindParam(":data_public", $data_public);
            $cst->bindParam(":desc", $desc);
            $cst->bindParam(":ctgJg", $ctgJg);
            $cst->execute();
            
            $idJg = $con->lastInsertId(); 
        
            $src = "usuarios/".$_SESSION['id']."/uf/jogos/".$idJg;
            mkdir($src, 0777, true);    
            
            $uploaddir = $src."/";
            $str =  basename($_FILES['arquivo']['name']);
            $ext = explode(".", $str);
            $ext = '.'.$ext[(count($ext)-1)];
            $nome_arquivo = $idJg."_file".$ext;
            $uploadfile = $uploaddir . $nome_arquivo;
    			     
            move_uploaded_file($_FILES['arquivo']['tmp_name'], $uploadfile);
            $zip->ziparArquivos($nome_arquivo,$nome_arquivo.".zip", $src."/");
            unlink($uploadfile);

            $sqlInto ="UPDATE arquivos SET name_arquivo = :nome_arquivo WHERE id = :idJg";
            $into =$con->prepare($sqlInto);
            $into ->bindValue(":nome_arquivo",$nome_arquivo);
            $into ->bindValue(":idJg",$idJg);
            $into->execute();
        
            $uploaddirC = $src."/";
            $strC =  basename($_FILES['imgInpGame']['name']);
            $extC = explode(".", $strC);
            $extC = '.'.$extC[(count($extC)-1)];
            $nome_arquivoC = $idJg."_capaGame".$extC;
            $uploadfileC = $uploaddirC . $nome_arquivoC;
    			     
            move_uploaded_file($_FILES['imgInpGame']['tmp_name'], $uploadfileC);

            $id = $_SESSION['id'];

            $cstFt = $con->prepare("UPDATE arquivos SET img_game = :img_capaGame WHERE id = :idJg;");
            $cstFt->bindParam(":idJg", $idJg);
            $cstFt->bindParam(":img_capaGame", $uploadfileC);
            $cstFt->execute();
		
            $arr = array('success' => '1'); 
            echo json_encode($arr);
        
    } catch (PDOException $ex) {

        echo 'erro '.$ex->getMessage();
    }

?>