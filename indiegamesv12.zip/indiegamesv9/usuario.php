<?php include "templates/topoL.php"; 
include "conexao/conexao.php";
$conecta = new Conexao();
?>



								<!-- LADO ESQUERDO -->
<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3 well">
      <div class="">
        <p><h3><?php echo $_SESSION['nome']; ?></h3></p>
        <img src="<?php
                    if($nm_ft == NULL){
                        echo "img/perfilDefault.jpg";
                    }else{
                        $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                        echo $localft;   
                    }                     
                  
                  ?>" id="imgPerfil" class="img-circle" height="150" width="150" alt="Avatar">    
       <br> 
<h5><?php echo  $_SESSION['nick']; ?></h5>	   
<br>	 
  
        <button onClick="carregaImg()" type="button" class="btn btn-default" data-toggle="modal" data-target="#modalFT_perfil"> 
		
		<span class="glyphicon glyphicon-camera"></span> </button>  
      </div>
	  <br>  
        <!-- Modal foto perfil-->
        <div id="modalFT_perfil" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <form method="post" enctype="multipart/form-data" id="form_ftPerfil">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Carregar foto de perfil</h4>
                    </div>
					<br>
                    <div class="modal-body">
                        <div class="row">
                          <img id="blah" src="
                          <?php 
                            if($nm_ft == NULL){
                                echo "img/perfilDefault.jpg";
                            }else{
                                $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                                echo $localft;   
                            }  
                          
                          ?>" alt="your image" accept='image/*' width="250px">
                        </div>
                        <center><input class="btn btn-default" type='file' name="imgInp" id="imgInp"></center>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-default" class="attFoto" type="submit">Atualizar foto</button>
                    </div>
                </form>  
            </div>
          </div>
        </div>
      <div class="well">
	  <br>
        <p><i class="fa fa-align-center" style="font-size:15px"></i> Biografia</p>
		
        <p>
          Criador de jogos independentes desde 2012
        </p>
      </div>
      
      <p><a href="#">Adicione um link</a></p>
      <p><a href="#">Adicione um link</a></p>
      <p><a href="#">Adicione um link</a></p>
	  
	  <br>
	  
	  
	  <a href="seguidos.php"><div class="well col-sm-6">
         <p>Seguindo</p>
		 <?php
		 try{
			 $sql="select * from seguindo where usuario_id=:idu";
			 $str=$con->prepare($sql);
			 $str->bindParam(':idu', $_SESSION['id']);
			 $str->execute();
			 $qtdSeguindo = $str->rowCount();
			 }catch(PDOException $e){
			 echo $e->getMessage();
		 }
		 ?>
		<p><strong><?php echo $qtdSeguindo;?></strong></p>
      </div></a>
       <a href="seguidores.php"><div class="well col-sm-6">
        <p>Seguidores</p>
		<?php
		try{		
			$sql ="select * from seguidores where usuario_id =:idu";
			$str=$con->prepare($sql);
			$str->bindParam(':idu', $_SESSION['id']);
			$str->execute();
			$qtdSeguidores= $str->rowCount();
		}catch(PDOException $e){
			echo $e->getMessage();
			}
		
		?>
		<p><strong><?php echo $qtdSeguidores;?> </strong></p>
      </div></a>
	  
    </div>
	
	
	
	
				<!-- MEIO -->
    <div class="col-sm-6">
    
      <div class="row">
        <div class="col-sm-12">
          <div class="well text-left">
		  
		  <!-- Modal Jogo-->
    <div class="modal fade" id="modalJogo" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:35px 50px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button><center>
                 <i class="material-icons" style="font-size:25px">gamepad</i></center>
                </div>
                <div class="modal-body" style="padding:40px 50px;">
                    <form role="form" enctype="multipart/form-data" name="uploadJg" method="post" data-toggle="validator" id="formJg">
                        <div class="form-group">
                            <label for="nomeJg">Nome do Jogo:</label>
                            <input type="text" class="form-control" name="nomejg" id="nomeJg" placeholder="Nome do Jogo" maxlength="40" required>
                            
                        </div>
                        <div class="form-group">
                            <label for="descJg"> Descrição do Jogo:</label>
                            <textarea class="form-control" name="descJg" id="descjg" placeholder="Descrição" maxlength="300" required></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="ctgJg"> Categoria do Jogo:</label>
                            <input type="text" class="form-control" name="ctgJg" id="ctgJg" placeholder="Categoria do Jogo" maxlength="25" required>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="psw">Selecione a capa do jogo</label>
                            <div class="row">
                              <center><img id="img_game" src="<?php echo "img/capa_indie.png";?>" alt="your image" accept="image/png, image/jpeg" height="100px"></center>
                            </div>
                            <center><input class="btn btn-default" type='file' name="imgInpGame" id="imgInpGame"></center>
                        
                        </div>
                       <center> <div class="form-group">
                            <label for="psw">Selecione o arquivo do jogo</label>
                            <input type="file" class="form-control" name="arquivo" required>
                            
                        </div>
                        <div class="form-group">
                            <button type="submit" id="btnCad" class="btn btn-default btn-block entrar" name="btnCadastro"  onClick="validaJg()">  Enviar Jogo</button>
                        </div>
                    </form></center>
                </div>
            </div>
        </div>
    </div><!-- .modal Jogo -->
            
             <form method="post" id="form_public">
                <div class="form-group">
                    <label for="comment">Publique algo:</label>
                    <textarea class="form-control" rows="5" id="post"></textarea>
				</div>
                  <button type="button" class="btn btn-default btn-sm" onclick="publicar()"><span class="glyphicon glyphicon-new-window"></span> Publicar
                    </button> <button id="bntjogo" onClick="carregaImg()" type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#modalJogo"> <i class="material-icons" style="font-size:15px">gamepad</i><span>Publicar Jogo</span></button> 
              </form>
                
                
				
			  
			   
            </div>
          </div>
        </div>
      
      <?php 
            $usuario_id = $_SESSION['id'];
            try{
                $cst = $conecta->conectar()->prepare("SELECT id_postagem, texto, data_postagem FROM `postagem` WHERE `usuario_id` = :usuario_id;");
                $cst->bindParam(":usuario_id", $usuario_id);
                $cst->execute();

                $rstPost = $cst->rowCount();
                $result = $cst->fetchAll(PDO::FETCH_ASSOC);
                
                for($i=$rstPost; $i>0; $i--){
                    
                    $aux = $result[$i-1]

         ?>
        
                    <div class="col-sm-12">
                        <div class="wellpost">
                            <div class="panel-body">
                                
                                    <div class="col-sm-3">
                                        <strong><p><?php echo $_SESSION['nome']; ?></p></strong>
                                        <img src="<?php
                                        if($nm_ft == NULL){
                                            echo "img/perfilDefault.jpg";
                                        }else{
                                            $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                                            echo $localft;   
                                        }                     

                                        ?>" class="img-circle" height="55" width="55" alt="Avatar"> <br><p class="nickpost"><br> <?php echo  $_SESSION['nick']; ?></p>
                                    </div>
                                
                                <div class="col-sm-9">
                                    <div><p class="datapost" id='data-post'><?php print_r($aux['data_postagem']);?></p><br>
                                        <p class="textopost"><?php print_r($aux['texto']);?></p>
                                       
                                    </div>
									<div><p class="curtida"> <i class="material-icons" style="font-size:15px">thumb_up</i>(0)</p>  </div>
                                </div>
                            </div>
                        </div>
                      </div>
                    
                    <?php 
                }
                
            } catch (PDOException $ex) {
                return 'erro '.$ex->getMessage();
            }
        
        ?>
             
            </div>
         
     
      
   
	
	<!-- LADO DIREITO -->
    <div class="col-sm-3 well">
      <div class="thumbnail">
        <p><h4><i class="material-icons" style="font-size:15px">gamepad</i> Recomendado</h4></p>
        <a href="#"><img src="img/jogo2.png"  width="200" height="200">
        <p><strong>Mega Malarque</strong></p></a>
        
        
      </div>
		<br>
		
	  <br>
	   <i class="material-icons" style="font-size:30px">people</i><br>
	  <p><h4>Sugestão de Usuários </h4></p>
      <a href="#"><div class="well col-sm-6">
         <p>AnaGames</p>
		<p><img src="img/perfilDefault.jpg" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
      <a href="#"><div class="well col-sm-6">
        <p>Rafael_java</p>
		<p><img src="img/perfilDefault.jpg" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
	  
	  <a href="#"><div class="well col-sm-6">
         <p>SophiaGamer</p>
		<p><img src="img/perfilDefault.jpg" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
      <a href="#"><div class="well col-sm-6">
        <p>AnaGames</p>
		<p><img src="img/perfilDefault.jpg" class="img-circle" height="45" width="45" alt="Avatar"></p>
      </div></a>
	  
    </div>
  </div>
</div>
        
<?php include "templates/footer.php";?>
        
<script>

    $("#imgInp").change(function(){
    readURL(this);
});

$("#imgInpGame").change(function(){
    readURL(this);
});
        $("#form_ftPerfil").submit(function (e) {
            e.preventDefault();
                var formData = new FormData(this);

    $.ajax({
        url: "ajaxUploadFt.php",
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function (data) {
            $('#imgPerfil').attr('src', data.img_profile+"?img="+(Math.random().toString(36).substr(2, 9)));
            $('#icone_profile').attr('src', data.img_profile+"?img="+(Math.random().toString(36).substr(2, 9)));
            $('#modalFT_perfil').modal('hide');
            
            
        },
        cache: false,
        contentType: false,
        processData: false,
        xhr: function() {  // Custom XMLHttpRequest
            var myXhr = $.ajaxSettings.xhr();
            if (myXhr.upload) { // Avalia se tem suporte a propriedade upload
                myXhr.upload.addEventListener('progress', function (evt) {
                    console.log(evt.lengthComputable); // false
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                       console.log(Math.round(percentComplete * 100) + "%");
                    }
                }, false);
            }
        return myXhr;
        }
    });

});

</script>        

</body>
</html>