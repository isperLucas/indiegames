<?php
include "conexao/conexao.php";
session_start();
$email = $_POST['email'];
$pass = $_POST['password'];
$pass= sha1($pass);

try {
	$sql= "select email, senha from usuario where id= :idu";
	$str=$con->prepare($sql);
	$str->bindParam(':idu', $_SESSION['id']);
	$str->execute();
	$result = $str->fetch();	
	if ($pass!= $result['senha']){
		echo "Senha incorreta!";
	}else {
	$sql="select email from usuario where email=:email";
	$str=$con->prepare($sql);
	$str->bindParam(':email', $email);
	$str->execute();
	$linhas=$str->rowCount();
	if ($linhas==0){
		$sql="update usuario set email=:email where id=:idu";
		$str=$con->prepare($sql);
		$str->bindParam(':idu', $_SESSION['id']);
		$str->bindParam(':email', $email);
		$str->execute();
		$_SESSION['user']=$email;
		echo "email alterado com sucesso";
	}else{
		echo "email já cadastrado!";
	}
}
}catch(PDOException $e){
	$e->getMessage();
}