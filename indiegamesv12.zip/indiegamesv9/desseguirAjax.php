	<?php
include "conexao/conexao.php";
session_start();
	try{
		$idUser= $_SESSION['id'];
		$idSeguido = $_GET['id_seguido'];
		$sql ="delete from seguindo where usuario_id = :idu and id_seguido= :ids;";
		$str=$con->prepare($sql);
		$str->bindParam(':idu', $idUser);
		$str->bindParam(':ids', $idSeguido);
		$str->execute();
        $idu=$_GET['id_seguido'];
		$ids=$_SESSION['id'];
		$sql ="delete from seguidores where usuario_id=:idu and id_seguidor=:ids";
		$str=$con->prepare($sql);
		$str->bindParam(':idu',$idu);
		$str->bindParam(':ids',$ids);
		$str->execute();
		$arr = array('seg'=>0);
		echo $ids. " deixou de seguir ". $idu. "<br>". json_encode($arr);	
	}catch(PDOException $e){
		echo json_encode($arr). $e->getMessage();
		echo "erro ao desseguir 2";
	}
?>