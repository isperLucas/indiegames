<?php
include "conexao/conexao.php";
session_start();
$senhaAtual = $_POST['senhaA'];
$novaSenha= $_POST['pass'];
$novaSenhaConfirm = $_POST['pass2'];
$senhaAtual=sha1($senhaAtual);

try {
	$sql="select senha from usuario where id=:idu";
	$str=$con->prepare($sql);
	$str->bindParam(':idu', $_SESSION['id']);
	$str->execute();
	$result=$str->fetch();
	if ($result['senha']!=$senhaAtual){
		echo "Senha incorreta". $result['senha']. '-'. $senhaAtual;
	}else if ($novaSenha == $novaSenhaConfirm){
		$novaSenha=sha1($novaSenha);
		$sql= "update usuario set senha=:senhanova where id=:idu";
		$str=$con->prepare($sql);
		$str->bindParam(':idu', $_SESSION['id']);
		$str->bindParam(':senhanova', $novaSenha);
		$str->execute();
		echo "senhas alteradas com sucesso";
	}else{
		echo "senhas diferentes";
	}
}catch(PDOException $e){
	$e->getMessage();
}

?>