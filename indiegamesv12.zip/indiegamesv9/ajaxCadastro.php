<?php
require_once 'classes/usuario.class.php';

$objUser = new Usuario();

$objUser->queryInsert($_POST);

?>

