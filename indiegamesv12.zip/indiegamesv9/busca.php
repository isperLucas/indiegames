<?php
include "templates/topoL.php";
require_once "conexao/conexao.php";
?>



<?php include "templates/userEsquerdo.php"; ?>
	
				<!-- MEIO -->
        <div class="col-sm-9">
    
      <div class="text-center">
			<h1>Resultados</h1>		
			<div id="buscaUser">
			
			<?php
if (isset($_POST['button'])){
	$b = '%'.$_POST['procurar'].'%';
}

$sql= "select id, nome, img_profile, nick from usuario where nome like :busca and id !=:idu;";
try{
	$busca = $con->prepare($sql);
	$busca->bindParam(":busca",$b);
	$busca->bindParam(':idu', $_SESSION['id']);
	$busca->execute();
	
}catch(PDOEXception $e){
		echo $e->getMessage();
}
echo "<br>". $busca->rowCount(). " Resultados para ". $b;
?>
        </div>
		
	
	
	
	 
	 
	<?php while ($result=$busca->fetch()){	?>

        <center> <div class="col-sm-6">
          <div class="wellbusca">
            <div class="panel-body">
        <div class="col-sm-5">
         
           <center> <h4><?php echo $result['nome'];?></h4>
            <img src="usuarios/<?php echo $result['id']."/uf/".$result['img_profile'];?>" class="img-circle" height="80" width="80" alt="Avatar"><br>
			<p style="margin-top:8px;"><?php echo $result['nick'];?></p></center></div><div class="col-sm-1">
            <?php
		try{
			$sql="select * from seguindo where usuario_id = :idu and id_seguido =:ids;";
			$str=$con->prepare($sql);
			$str->bindParam(':idu', $_SESSION['id']);
			$str->bindParam(':ids', $result['id']);
			$str->execute();
			$qtdS=$str->rowCount();
		}catch(PDOEXception $e){
			$e->getMessage();
		}
	
			?>
			
			<?php
			if ($qtdS==0){
				
	?>
	<button class="btn btn-default btn-primary"   type="submit" style="margin-top:35px; width:113px; height:91px; margin-left:45px;"><strong><p>Seguir</p></strong><i class="material-icons" onclick="seguir(<?php echo $result['id']?>,this);" id="icoSeguir" style="font-size:50px;">&#xe7fe;</i></button>
		<?php }else{
			?>
			<button class="btn btn-default btn-danger"  type="submit" style="margin-top:35px; width:113px; height:91px; margin-left:45px;"><p style="font-size:12px;"><strong>Deixar de seguir</strong></p><i class="material-icons" id="icoSeguir"  onclick="desseguir(<?php echo $result['id']?>,this);"  style="font-size:50px;">&#xe7fd;</i></button>
		<?php }?>
         
        </a></div>

        
	  </div>
	  </div>
		</div>  
	  </center>
          <?php } ?>
    </div>
    </div>
	 
	  
	  
    </div>
    </div>
	
	
	<!-- LADO DIREITO -->
    
</div></center>
        

        
<script>

    $("#imgInp").change(function(){
    readURL(this);
});

$("#imgInpGame").change(function(){
    readURL(this);
});
        $("#form_ftPerfil").submit(function (e) {
            e.preventDefault();
                var formData = new FormData(this);

    $.ajax({
        url: "ajaxUploadFt.php",
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function (data) {
            $('#imgPerfil').attr('src', data.img_profile+"?img="+(Math.random().toString(36).substr(2, 9)));
            $('#icone_profile').attr('src', data.img_profile+"?img="+(Math.random().toString(36).substr(2, 9)));
            $('#modalFT_perfil').modal('hide');
            
            
        },
        cache: false,
        contentType: false,
        processData: false,
        xhr: function() {  // Custom XMLHttpRequest
            var myXhr = $.ajaxSettings.xhr();
            if (myXhr.upload) { // Avalia se tem suporte a propriedade upload
                myXhr.upload.addEventListener('progress', function (evt) {
                    console.log(evt.lengthComputable); // false
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                       console.log(Math.round(percentComplete * 100) + "%");
                    }
                }, false);
            }
        return myXhr;
        }
    });

});

</script>        






	


<?php

include "templates/footer.php";
?>