-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24-Abr-2017 às 18:52
-- Versão do servidor: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gw`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivos`
--

CREATE TABLE `arquivos` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_public` date DEFAULT NULL,
  `qtd_curtida` int(11) DEFAULT NULL,
  `qtd_coment` int(11) DEFAULT NULL,
  `name_arquivo` varchar(25) DEFAULT NULL,
  `descricao` text,
  `qtd_downloads` int(11) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `img_game` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `arquivos`
--

INSERT INTO `arquivos` (`id`, `nome`, `usuario_id`, `data_public`, `qtd_curtida`, `qtd_coment`, `name_arquivo`, `descricao`, `qtd_downloads`, `categoria`, `img_game`) VALUES
(9, 'Jonas Owerge', 7, '0000-00-00', NULL, NULL, '9_file.png', 'egerheheheh', NULL, 'ehethetheth', 'usuarios/7/uf/jogos/9/9_capaGame.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario_jogo`
--

CREATE TABLE `comentario_jogo` (
  `id_coment` int(11) NOT NULL,
  `jogo_id` int(11) NOT NULL,
  `data_coment` date DEFAULT NULL,
  `texto` text,
  `qtd_curtida` int(11) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario_postagem`
--

CREATE TABLE `comentario_postagem` (
  `id_postagem` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `texto` text,
  `data_comentario_postagem` date NOT NULL,
  `qtd_curtidas_comentario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtida_comentario_jogo`
--

CREATE TABLE `curtida_comentario_jogo` (
  `id_coment` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtida_comentari_postagem`
--

CREATE TABLE `curtida_comentari_postagem` (
  `usuario_id` int(11) NOT NULL,
  `id_postagem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtida_jogo`
--

CREATE TABLE `curtida_jogo` (
  `arquivos_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtida_postagem`
--

CREATE TABLE `curtida_postagem` (
  `id_postagem` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `postagem`
--

CREATE TABLE `postagem` (
  `id_postagem` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_postagem` date DEFAULT NULL,
  `texto` text,
  `qtd_curtidas` int(11) DEFAULT NULL,
  `qtd_comentarios` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `seguidores`
--

CREATE TABLE `seguidores` (
  `usuario_id` int(11) NOT NULL,
  `id_seguidor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `seguidores`
--

INSERT INTO `seguidores` (`usuario_id`, `id_seguidor`) VALUES
(7, 7),
(7, 8);

-- --------------------------------------------------------

--
-- Estrutura da tabela `seguindo`
--

CREATE TABLE `seguindo` (
  `usuario_id` int(11) NOT NULL,
  `id_seguido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `seguindo`
--

INSERT INTO `seguindo` (`usuario_id`, `id_seguido`) VALUES
(7, 7),
(8, 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `nick` varchar(45) NOT NULL,
  `dt_nasc` date DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `dt_cadastro` date DEFAULT NULL,
  `img_profile` varchar(45) DEFAULT NULL,
  `ip` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `nick`, `dt_nasc`, `email`, `senha`, `dt_cadastro`, `img_profile`, `ip`) VALUES
(7, 'Jonas Oliveira', 'Jonas013', NULL, 'jonasifsp@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '0000-00-00', '7_profile.jpg', NULL),
(8, 'Diego', 'Diego013', NULL, 'd@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '0000-00-00', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arquivos`
--
ALTER TABLE `arquivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_arquivos_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `comentario_jogo`
--
ALTER TABLE `comentario_jogo`
  ADD PRIMARY KEY (`id_coment`),
  ADD KEY `fk_comentario_jogo_arquivos1_idx` (`jogo_id`),
  ADD KEY `fk_comentario_jogo_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `comentario_postagem`
--
ALTER TABLE `comentario_postagem`
  ADD PRIMARY KEY (`id_postagem`),
  ADD KEY `fk_comentario_postagem_postagem1_idx` (`id_postagem`),
  ADD KEY `fk_comentario_postagem_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `curtida_comentario_jogo`
--
ALTER TABLE `curtida_comentario_jogo`
  ADD PRIMARY KEY (`id_coment`,`usuario_id`),
  ADD KEY `fk_curtida_comentario_jogo_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `curtida_comentari_postagem`
--
ALTER TABLE `curtida_comentari_postagem`
  ADD PRIMARY KEY (`usuario_id`,`id_postagem`),
  ADD KEY `fk_curtida_comentari_postagem_comentario_postagem1_idx` (`id_postagem`);

--
-- Indexes for table `curtida_jogo`
--
ALTER TABLE `curtida_jogo`
  ADD PRIMARY KEY (`arquivos_id`,`usuario_id`),
  ADD KEY `fk_curtida_jogo_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `curtida_postagem`
--
ALTER TABLE `curtida_postagem`
  ADD PRIMARY KEY (`usuario_id`,`id_postagem`),
  ADD KEY `fk_curtida_postagem1_idx` (`id_postagem`);

--
-- Indexes for table `postagem`
--
ALTER TABLE `postagem`
  ADD PRIMARY KEY (`id_postagem`,`usuario_id`),
  ADD KEY `fk_postagem_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `seguidores`
--
ALTER TABLE `seguidores`
  ADD PRIMARY KEY (`usuario_id`,`id_seguidor`),
  ADD KEY `fk_seguidores_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `seguindo`
--
ALTER TABLE `seguindo`
  ADD PRIMARY KEY (`usuario_id`,`id_seguido`),
  ADD KEY `fk_seguindo_usuario1_idx` (`usuario_id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arquivos`
--
ALTER TABLE `arquivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `postagem`
--
ALTER TABLE `postagem`
  MODIFY `id_postagem` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `arquivos`
--
ALTER TABLE `arquivos`
  ADD CONSTRAINT `fk_arquivos_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `comentario_jogo`
--
ALTER TABLE `comentario_jogo`
  ADD CONSTRAINT `fk_comentario_jogo_arquivos1` FOREIGN KEY (`jogo_id`) REFERENCES `arquivos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_comentario_jogo_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `comentario_postagem`
--
ALTER TABLE `comentario_postagem`
  ADD CONSTRAINT `fk_comentario_postagem_postagem1` FOREIGN KEY (`id_postagem`) REFERENCES `postagem` (`id_postagem`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_comentario_postagem_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `curtida_comentario_jogo`
--
ALTER TABLE `curtida_comentario_jogo`
  ADD CONSTRAINT `fk_curtida_comentario_jogo_comentario_jogo1` FOREIGN KEY (`id_coment`) REFERENCES `comentario_jogo` (`id_coment`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curtida_comentario_jogo_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `curtida_comentari_postagem`
--
ALTER TABLE `curtida_comentari_postagem`
  ADD CONSTRAINT `fk_curtida_comentari_postagem_comentario_postagem1` FOREIGN KEY (`id_postagem`) REFERENCES `comentario_postagem` (`id_postagem`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curtida_comentari_postagem_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `curtida_jogo`
--
ALTER TABLE `curtida_jogo`
  ADD CONSTRAINT `fk_curtida_jogo_arquivos1` FOREIGN KEY (`arquivos_id`) REFERENCES `arquivos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curtida_jogo_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `curtida_postagem`
--
ALTER TABLE `curtida_postagem`
  ADD CONSTRAINT `fk_curtida_postagem1` FOREIGN KEY (`id_postagem`) REFERENCES `postagem` (`id_postagem`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curtida_postagem_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `postagem`
--
ALTER TABLE `postagem`
  ADD CONSTRAINT `fk_postagem_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `seguidores`
--
ALTER TABLE `seguidores`
  ADD CONSTRAINT `fk_seguidores_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `seguindo`
--
ALTER TABLE `seguindo`
  ADD CONSTRAINT `fk_seguindo_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
