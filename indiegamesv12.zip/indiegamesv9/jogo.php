<?php
include "templates/topoL.php";

$id_jogo = 9;

$cst = $con->conectar()->prepare("SELECT `id`, `nome`, `usuario_id`, `data_public`, `qtd_curtida`, `qtd_coment`, `name_arquivo`, `descricao`, `qtd_downloads`, `img_game`, `categoria` FROM `arquivos` WHERE `id` = :id_jogo");
$cst->bindParam(':id_jogo', $id_jogo);
$cst->execute();
$rst = $cst->fetch();

$_SESSION['nm_jogo'] = $rst['nome'];
$_SESSION['categoria'] = $rst['categoria'];
$_SESSION['desc_jogo'] = $rst['descricao'];
$id_user =  $rst['usuario_id'];
$_SESSION['img_game'] = $rst['img_game'];

$cstUser = $con->conectar()->prepare("SELECT id, nome, nick, dt_nasc, email, senha, dt_cadastro FROM `Usuario` WHERE `id` = :id_user;");
$cstUser->bindParam(':id_user', $id_user);
$cstUser->execute();
$rstUser = $cstUser->fetch();

$_SESSION['nm_usuario'] = $rstUser['nick'];



?>

<div class="container text-center well">    
  
    <div class="col-sm-6">
      
	  <h2><?php echo $_SESSION['nm_jogo'] ?> </h2><br>
	   <h4><strong>Por:</strong><?php echo $_SESSION['nm_usuario'] ?></h4>
	  <h4><strong>Estilo: </strong><?php echo $_SESSION['categoria'] ?></h4><br>
	 
	  <p><?php echo $_SESSION['desc_jogo'] ?></p>

	  </div>
	

	    <div class="col-sm-6 ">
		<div class="col-sm-12" >
		<center><img src="<?php echo $_SESSION['img_game']?>" class="img-responsive"  alt="Image" id="capajogo"></center><br><br><br>
		
		</div>
		</div>
		
		<hr>
		<div class="container text-center">
		
	<center><button class="btn btn-default" style="width:180px; height:100px; font-size:30px;">Baixar</button></center><br>
		</div>
		</div>
        
<?php include "templates/footer.php";?>
        



