<?php
    include_once "classes/conexao.class.php";
    $con = new Conexao();
    
    session_start();

    $post = $_POST['post'];
    $usuario_id = $_SESSION['id'];
   
        
    try{
        $cst = $con->conectar()->prepare("INSERT INTO `postagem` (usuario_id, data_postagem, texto) VALUES (:usuario_id, now(), :texto);");
        $cst->bindParam(":usuario_id", $usuario_id);
     
        $cst->bindParam(":texto", $post);
        $cst->execute();
        
        $arr = array('success' => '1');
        echo json_encode($arr);
        
    } catch (PDOException $ex) {
        return 'erro '.$ex->getMessage();
    }

?>