<?php
include "templates/topoL.php";
require_once "conexao/conexao.php";
?>


<?php

//if ($valor=$str->fetch()){
?>
	<center>
<div class="container" style="margin-bottom:200px;">
  <h2>Pagina de configurações</h2>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#user">Usuario</a></li>
    <li><a data-toggle="tab" href="#conta">Conta</a></li>
 
  </ul>

  <div class="tab-content">
    <div id="user" class="tab-pane fade in active">
      <h3>Configurações de Usuario</h3>
    
 
      <hr>
    <!-- Configurações de usuário -->
    <div class="row">
      <div class="col-sm-3">

      </div>
    </div>
    <div class="row">
      <form method="post" action="alteraUser.php">
          <div class="col-sm-9">
            <div class="input-group">
             <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
             <input id="nome" type="text" class="form-control" name="nomeUser" placeholder="Nome" value="<?php echo $_SESSION['nome'];?>">
            </div>
        </div>
        <div class="col-sm-9">
          <div class="input-group">
            <span class="input-group-addon"><i class="material-icons">account_circle</i></span>
            <input id="nick" type="text" class="form-control" name="nick" value="<?php echo $_SESSION['nick'];?>" >
          </div>
        </div>
     
      
      	
    		<div class="col-sm-9" >
        <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span> 
          <input id="nasc" type="date" class="form-control" name="nascUser" placeholder="Email" value="<?php echo $_SESSION['dt_nasc'];?>">
             
        </div>
      </div>
  	<div class="col-sm-4"></div>
  	
  	
  	<div class="col-sm-4">
  	
  <button  class="form-control btn-success" style="margin-top:10px;"><span class="glyphicon glyphicon-floppy-disk"></span> Salvar</button>

  </div>
  	<div class="col-sm-4"></div>
</form> 
</div>
 <div class="row">
      <div class="col-sm-3">
        
      </div>
    </div>
    </div>
	  <!-- //Menu 1 -->
	  
	  
	    <!-- Menu 2 -->

   
    <div id="conta" class="tab-pane fade" style="margin-bottom:129px;">

     
      <div class="container" style="background-color:white;">
         <h3 style="text-align:center;">Configurações de Conta</h3>
<script>
  $(function(){
$("#formulario").validate({
	rules :{
		email: {
			required:true,
			
		},
		password:{
			required:true,
			minlength:6,
		},
		
	},
	messages :{
		email :{
			required:"Email obrigatório",
			email: "Email Invalido",
		},
		password :{
			required : "Informe uma senha",
			minlength: "mínimo 6 digitos",
		},
	
		
	}
});

$("#formularioS").validate({
 rules:{
	senhaA:{
			required:true,
			minlength:6,
		},
		pass :{
			required:true,
			minlength:6,
		},
		pass2 :{
			required:true,
			minlength:6,
			equalTo:'#pass',
		},
 },
	messages:{
		senhaA:{
			required: "Senha atual é obrigatória",
			minlength: "mínimo 6 digitos",
		},
		pass:{
			required:"digite a nova senha",
			minlength :"mínimo 6 digitos",
		},
		pass2:{
			required:"confirme sua nova senha",
			minlength:"mínimo 6 digitos",
			equalTo:"As senhas devem ser iguais!",
		}
		}
 });
  });
</script> 
  <a href="#" data-toggle="modal" data-target="#myModal" >Alterar email</a><br>

  <!-- Modal alterar email -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Alterar Email</h4>
        </div>
        <div class="modal-body">
            <form class="col-sm-12" id="formulario" action="updateUser.php">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="email" type="text" class="form-control required email" name="email" placeholder="Email" value="<?php echo $_SESSION['email'];?>" >
    </div>
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control required" name="password" placeholder="Password" >
    </div>
	<div id="ack"></div>
    <div class= "input-group">
    <button class="btn btn-success" id="btnAltera" style="margin-top:10px">Alterar</button>
    </div>
    <br>
	 
   
  </form>
        </div>
        <div class="modal-footer">
		
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  
  
  <a  href= "#" data-toggle="modal" data-target="#myModal2">Alterar Senha</a>

  <!-- Moda alterar senha -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Alterar Senha</h4>
        </div>
        <div class="modal-body">
            <form class="col-sm-12" id="formularioS" action="updateSenha.php" method="POST">
            <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control required" name="senhaA" placeholder="Senha atual" >
    </div>
 <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="pass" type="password" class="form-control required" name="pass" placeholder="nova senha" >
    </div>
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="pass2" type="password" class="form-control required" name="pass2" placeholder="Confirmar nova senha" >
    </div>
	<div id="abc"></div>
    <div class= "input-group">
    <button class="btn btn-success" id="btnAltera2" style="margin-top:10px">Alterar</button>
    </div>
    <br>
   
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  
 
  <script>
  $("#btnAltera").click(function(){
	$.post($("#formulario").attr("action"),
	$("#formulario :input").serializeArray(),
	function(data){
		$("#ack").html(data);
	
	});
	$("#formulario").submit(function(){
		return false;
	});
  });
  //Mensagens de alteração de senha
    $("#btnAltera2").click(function(){
	$.post($("#formularioS").attr("action"),
	$("#formularioS :input").serializeArray(),
	function(data){
		$("#abc").html(data);
	
	});
	$("#formularioS").submit(function(){
		return false;
	});
  });
  </script>


  <br>


</div>
    </div>
    <!-- // Menu 2 -->

    


  
</div>
</div>
</center>


<!------------- FIM -->

<?php include "templates/footer.php";?>