<?php
class Zipar {
    
	function ziparArquivos($arquivo, $nomeZip,$caminho){
		$zip = new ZipArchive();
		if ($zip->open($caminho.$nomeZip, ZIPARCHIVE::CREATE)!=TRUE){

		}
		$zip->addFile($caminho.$arquivo,$arquivo);
		$zip->close();
		return true;
	
	}
}
?>
