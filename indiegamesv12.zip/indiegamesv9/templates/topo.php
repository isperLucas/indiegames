<!DOCTYPE html>
<html lang="en">
<head>
<title>IndieGames</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap Css -->
<link rel="stylesheet" href="bootstrap/dist/css/bootstrap.css" >    

<!-- Bootstrap JQuery -->
<script src="bootstrap/dist/js/jquery.js"></script>  

<!-- Bootstrap Java Script -->
<script src="bootstrap/dist/js/bootstrap.js"></script> 
<script src="js/validator.js"></script>      

<!-- Bootstrap Fonts --> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
<!-- Style Css -->   

<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">  


<!-- Scripts -->   
<script src="js/script.js?sdfsdfsdfsdfsadfsdf"></script>
    
<link rel="shortcut icon" href="img/logo_ico.ico" type="image/x-icon" />    

<script async="async" src="https://www.googletagservices.com/tag/js/gpt.js"></script>

<!-- Nosso css -->   

<link rel="stylesheet" href="css/styles.css?dhhd">  
</head>
<body>
    <div id="bannerHome">
    <img class="img-responsive" src="img/logov4_capa2.png" >
    </div>

    <!-- Nav -->
    <nav class="navbar navbar-inverse" id="navBar">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                </button>
                <a class="navbar-static-top" href="#"><img id="logo" src="img/logov4.png" height="30px"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="#">Início</a></li>
                    <li><a href="#">Sobre</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 10px;">
                    <li id="btnModalCad" data-toggle="modal" data-target="#modalCad"><a href="#"><span class="glyphicon glyphicon-user"></span> Cadastrar</a></li>
                    <ul class="nav navbar-nav navbar-right">
                    <li id="btnModalLog" data-toggle="modal" data-target="#modalLog"><a href="#"><span class="glyphicon glyphicon-log-in"></span> Entrar</a></li>
                    </ul>
                </ul>    
            </div>
        </div>
    </nav><!--Nav -->
    
    <!-- Modal Cadastro-->
    <div class="modal fade" id="modalCad" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:35px 50px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <center> <span class="glyphicon glyphicon-user" style="font-size:50px"></span>  <h4> Cadastre-se na Indie Games</h4></center>
                </div>
                <div class="modal-body" style="padding:40px 50px;">
                    <form role="form"  method="post" name="formu" data-toggle="validator" id="formCad">
                        <div class="form-group">
                            <label for="usrname"><span class="glyphicon glyphicon-user"></span>  Nome Completo:</label>
                            <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome" maxlength="30" required>
                            
                        </div>
                        <div class="form-group">
                            <label for="nickname"><strong>@</strong>  Nome de Usuário:</label>
                            <input type="text" class="form-control" name="nick" id="nick" placeholder="Usuário" maxlength="15" required>
                            <div class="help-block with-errors"></div>
                            <div class="alert alert-danger" style="display:none" id="error_userExistente">
                                Nome de usuario já cadastrado
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email"><span class="glyphicon glyphicon-envelope"></span>  Email:</label>
                            <input type="email" class="form-control" data-error="Por favor, informe um e-mail correto." required name="email" id="email" placeholder="Email">
                            <div class="help-block with-errors"></div>
                            <div class="alert alert-danger" style="display:none" id="error_emailExistente">
                                Email já cadastrado
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="senha"><span class="glyphicon glyphicon-lock"></span>  Senha</label>
                            <input type="password" class="form-control" data-minlength="6" name="senha" id="senha" placeholder="Senha"  required>
                             
                        </div>
                        <div class="form-group">
                            <label for="psw"><span class="glyphicon glyphicon-lock"></span>  Confirmar Senha</label>
                            <input type="password" class="form-control" name="confirmarSenha" data-match="#senha" data-match-error="Atenção! As senhas não estão iguais." id="psw" placeholder="Senha" required >
                             <div class="help-block with-errors"></div> 
                        </div>
                        <div class="form-group">
                            <button type="submit" id="btnCad" class="btn btn-default btn-block entrar" name="btnCadastro"  onClick="validaCad()">  Cadastrar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- .modal Cadastro -->

    <!-- Modal Login -->
    <div class="modal fade" id="modalLog" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:35px 50px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <center><span class="glyphicon glyphicon-log-in" style="font-size:50px"></span><h4>Entrar na Indie Games</h4> </center>
                </div>
                <div class="modal-body" style="padding:40px 50px;">
                    <form role="form" method="post">
                        <div class="form-group">
                            <label for="usrname"><span class="glyphicon glyphicon-user"></span> Usuário</label>
                            <input type="text" class="form-control" name="emailUser_login" id="email_login" placeholder="Nome do Usuário">
                        </div>
                        <div class="form-group">
                            <label for="psw"><span class="glyphicon glyphicon-lock"></span> Senha</label>
                            <input type="password" class="form-control" name="senhaUser_login" id="senha_login" placeholder="Senha"> 
                            <div class="alert alert-danger alert-block alert-aling" role="alert" style="display:none" id="errorLogin">Ops! E-mail ou Senha estão errado</div>
                        </div>
                        <div class="checkbox">
                            <label><input type="checkbox" value="" checked>Lembrar de mim</label>
                        </div>
                        <span onclick="validacaoLogin();" name="btLogar" class="btn btn-default btn-block entrar"><strong> Entrar </strong> </span>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-default pull-left cancelar" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancelar</button>
                    
                    <p>Esqueceu a <a href="#">Senha?</a></p>
                </div>
            </div>
        </div>
    </div><!-- .modal Login --> 
 
    <script>
   $(document).scroll(function(){
        if($('#bannerHome').is(':appeared')){
            $("#navBar").removeClass("navbar-fixed-top");
        } else{
            $("#navBar").addClass("navbar-fixed-top");
        }
    });
          
   
    </script>        