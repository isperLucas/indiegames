<footer class="container-fluid text-center">

<br>
<img src="img/logov4.png" height="42px">
<br>
<br>

  <p>Copyright © 2017 - Todos direitos reservados equipe <a href="jlddesenvolvimento/index.html">JLD Desenvolvimento</a> </p>  
</footer>
</body>
</html>