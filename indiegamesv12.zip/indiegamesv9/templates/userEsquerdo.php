<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3 well">
      <div class="">
        <p><h3><?php echo $_SESSION['nome']; ?></h3></p>
        <img src="<?php
                    if($nm_ft == NULL){
                        echo "img/perfilDefault.jpg";
                    }else{
                        $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                        echo $localft;   
                    }                     
                  
                  ?>" id="imgPerfil" class="img-circle" height="150" width="150" alt="Avatar">    
       <br>  
<br>	   
        <button onClick="carregaImg()" type="button" class="btn btn-default" data-toggle="modal" data-target="#modalFT_perfil"> 
		
		<span class="glyphicon glyphicon-camera"></span> </button>  
      </div>
	  <br>  
        <!-- Modal foto perfil-->
        <div id="modalFT_perfil" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <form method="post" enctype="multipart/form-data" id="form_ftPerfil">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Carregar foto de perfil</h4>
                    </div>
					<br>
                    <div class="modal-body">
                        <div class="row">
                          <img id="blah" src="
                          <?php 
                            if($nm_ft == NULL){
                                echo "img/perfilDefault.jpg";
                            }else{
                                $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                                echo $localft;   
                            }  
                          
                          ?>" alt="your image" accept='image/*' width="250px">
                        </div>
                        <center><input class="btn btn-default" type='file' name="imgInp" id="imgInp"></center>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-default" class="attFoto" type="submit">Atualizar foto</button>
                    </div>
                </form>  
            </div>
          </div>
        </div>
      <div class="well">
	  <br>
        <p><i class="fa fa-align-center" style="font-size:15px"></i> Biografia</p>
		
        <p>
          Criador de jogos independentes desde 2012
        </p>
      </div>
    
	  
	  <a href="seguidos.php"><div class="well col-sm-6">
         <p>Seguindo</p>
		 <?php
		 try{
			 $sql="select * from seguindo where usuario_id=:idu";
			 $str=$con->prepare($sql);
			 $str->bindParam(':idu', $_SESSION['id']);
			 $str->execute();
			 $qtdSeguindo = $str->rowCount();
			 }catch(PDOException $e){
			 echo $e->getMessage();
		 }
		 ?>
		<p><strong><?php echo $qtdSeguindo;?></strong></p>
      </div></a>
      <a href="seguidores.php"><div class="well col-sm-6">
        <p>Seguidores</p>
		<?php
		try{		
			$sql ="select * from seguidores where usuario_id =:idu";
			$str=$con->prepare($sql);
			$str->bindParam(':idu', $_SESSION['id']);
			$str->execute();
			$qtdSeguidores= $str->rowCount();
		}catch(PDOException $e){
			echo $e->getMessage();
			}
		
		?>
		<p><strong><?php echo $qtdSeguidores;?> </strong></p>
      </div></a>
	  
    </div>
	
	
	