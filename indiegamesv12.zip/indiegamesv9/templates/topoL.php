<?php
//BUSCANDO AS CLASSES
require_once 'classes/usuario.class.php';
require_once 'classes/conexao.class.php';
//ESTANCIANDO 
$objFunc = new Usuario();
$con = new Conexao();
//VALIDANDO USUARIO
session_start();
if($_SESSION["logado"] == "sim"){
	$objFunc->UserLogado($_SESSION['user']);
}else{
	header("location: index.php"); 
}

if(isset($_GET['sair']) == "sim"){
	$objFunc->sairUser();
}

//SESSIONS
$email = $_SESSION['user'];
try{
    $cst = $con->conectar()->prepare("SELECT `id`, `nick`, `dt_nasc`, `dt_cadastro`, `img_profile`,`email` FROM `usuario` WHERE `email` = :email;");
    $cst->bindParam(':email', $email, PDO::PARAM_STR);
    $cst->execute();
        $rst = $cst->fetch();
        $_SESSION['id'] = $rst['id'];
        $_SESSION['nick'] = $rst['nick'];
		$_SESSION['email']=$rst['email'];
        $_SESSION['dt_nasc'] = $rst['dt_nasc'];;
        $_SESSION['img_profile'] = $rst['img_profile'];

}catch(PDOException $e){
    return 'Error: '.$e->getMassage();
}


$nm_ft = $_SESSION['img_profile'];     
?>
	<html lang="en">
		<head>
<title>Indie Games</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="img/logo_ico.ico" type="image/x-icon" />
<!-- Bootstrap Css -->

<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/bootstrap-theme.css">




<!-- Bootstrap JQuery -->
<script src="bootstrap/dist/js/jquery.js"></script>  

<!-- Bootstrap Java Script -->

<script src="bootstrap/dist/js/bootstrap.js"></script> 
<script src="js/validator.js"></script> 
<script type="text/javascript" src="js/jquery.validate.min.js"></script>     

<!-- Bootstrap Fonts --> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
<!-- Style Css -->   
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
<!-- Scripts -->   
<script src="js/script.js?frgfgfgfgfg"></script>

<!-- Nosso Css -->
<link rel="stylesheet" type="text/css" href="css/styles.css?abcdeas" >	
		</head>
			<body>
								<!-- MENU -->
				<nav class="navbar navbar-inverse navbar-fixed-top " >
					<div class="container-fluid">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>                        
							</button>
							
							<a class="navbar-static-top" href="#"><img  src="img/logov4.png"  id="logo"  height="30px"  > </a>
							</div>
					<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav">
						<li><a href="usuario.php">  Início</a></li>
			
							<!-- <li class="navbar-form " ><img  src="logov4.png"  height="36px"  ></img></li> -->
							</ul>
							<ul class="nav navbar-nav navbar-right">
													<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-globe"></span> Notificações</a><ul class="dropdown-menu">
          <li><a href="#">Avaliação (2)</a></li>
          <li><a href="#">Comentarios (1) </a></li>
          <li><a href="#">Seguindo (3)</a></li>
        </ul>
      </li>

			<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"> <img src="
                <?php 
                    if($nm_ft == NULL){
                        echo "img/perfilDefault.jpg";
                    }else{
                        $localft = "usuarios/".$_SESSION['id']."/uf/".$nm_ft;
                        echo $localft;   
                    }  
                ?>" class="img-circle" height="21" width="21" alt="Avatar" id="icone_profile">  <?php echo  $_SESSION['nick']; ?></a>	
           
            <ul class="dropdown-menu">
             <center> <li><button class="btn btn-default"><a href="usuario.php">Perfil</a></button></li></center>
              <center><li><button class="btn btn-default"><a href="configUser.php">Configurações</a></button></li></center>
                <form method="get">     
                  <li><center><button class="btn btn-default" name="sair">Sair</button></li></center>
                </form>
            </ul>
          </li>


          </ul> <center>
	
		  
  
      <form class="navbar-form" method="post" role="search" action="busca.php">
        <div class="form-group input-group">
          <input type="text" class="form-control" placeholder="" name="procurar">
          <span class="input-group-btn">
            <input class="btn btn-default " type="submit" name="button" value="Buscar" > </input>
           
            
        </span>        
        </div>
      </form>
	  
	  
	  
	  </center>
			
    </div>
  </div>
  </nav>

