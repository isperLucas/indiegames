<?php
include "conexao/conexao.php";
 session_start();
try{
    $id_usuario= $_SESSION['id']; // id do usuário que está seguindo
    $ids=$_GET['id_seguido']; //idecho $id_user . " está seguindo ". $id_seguido ."<br>"; de quem está sendo seguido
	$sql="select * from seguindo where usuario_id = :uid and id_seguido = :ids ;";
	$strm=$con->prepare($sql);
    $strm->bindParam('uid',$_SESSION['id']);
    $strm->bindParam('ids', $ids);
	$strm->execute();
	$qtdLinhas = $strm->rowCount();
    if ($qtdLinhas>0){
		$arr = array('seg'=>$qtdLinhas);
		echo json_encode($arr);
	}else{
		$id_user = $_SESSION['id'];
        $id_seguido =$_GET['id_seguido'];
        $sql= "insert into seguindo(usuario_id,id_seguido)values(:idu,:ids);";
        $str= $con->prepare($sql);
        $str-> bindParam(':idu', $id_user);
        $str-> bindParam(':ids', $id_seguido);
		$arr = array('seg'=>1);
		echo $id_user . " está seguindo ". $id_seguido ."<br> ". json_encode($arr);
        $str->execute();
	try{
		$sql= "insert into seguidores(usuario_id, id_seguidor) values (:idu,:ids);";
		$str=$con->prepare($sql);
		$str->bindParam(':idu',$_GET['id_seguido']);
		$str->bindParam(':ids', $_SESSION['id']);
		$str->execute();
	}catch(PDOException $e){
		$e->getMessage();
	}
	}
}
catch(PDOException $e){
	echo json_encode($arr). $e->getMessage();
    
}
?>

