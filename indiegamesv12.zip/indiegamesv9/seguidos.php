<?php include "templates/topoL.php";
 include "conexao/conexao.php";
 include "templates/userEsquerdo.php"
 ?>


		<div class="col-sm-9">
    
      <div class="text-center">
	  
	  
 <?php 
				 try{
				 $sql = "select nome,nick, id_seguido,img_profile 
						from usuario inner join seguindo 
						where usuario_id=:idu and id_seguido=id"; // usuario_id se refere a chave primaria da tabela 'seguindo', id=pk tabela usuario
				 $str=$con->prepare($sql);
				 $str->bindParam(':idu', $_SESSION['id']);
				 $str->execute();
				 }catch(PDOException $e){
					 echo $e->getMessage();
				 }
				 ?>
<div class="PaginaSeguidos">
	<div class="row" >

		<div class="userDiv" id="conteudo"  >
			<h3 class="text-center">Quem Você Segue!</h3>
			
				<!--
				<div class='bloco'>
					<div class='col-sm-3' style='border:1px solid black;'>
					<img src='img/rob.jpg' width='55px' height='55px' id='img' style='float:left'>
					
					<strong><p style='float:left;'>Nick</p></strong>
					
			
						<button style='float:left;' > <i class='material-icons'>person_add</i>
						</button>
					</div>
				</div>
				 -->
				 
				<?php 
				while($result=$str->fetch()){
					
				?>
				<div class="col-sm-6">
         <div class="wellbusca">
            <div class="panel-body">
       <div class="col-sm-5">
         
           <h4> <?php echo $result['nome'];?></h4>
            <img src="usuarios/<?php echo $result['id_seguido']."/uf/".$result['img_profile'];?>" class="img-circle" height="80" width="80" alt="Avatar"><p style="margin-top:8px;"><?php echo $result['nick'];?></p></div><div class="col-sm-4">
			
         
        </div>
		 <button class="btn btn-default btn-danger"  type="submit" style="margin-top:35px; width:113px; height:91px; margin-left:45px;"><p style="font-size:12px;"><strong>Deixar de seguir</strong></p><i class="material-icons" onclick="desseguir(<?php echo $result['id_seguido']?>,this);" id="icoSeguir" style="font-size:50px;">&#xe7fd;</i></button>
        
	  </div>
	  </div>
		</div>
				
				
				<?php }
				
				?>



  









  
  
</div>
</div>
</div>
</div>
</div>
</div>
</div>




<?php include "templates/footer.php";?>

