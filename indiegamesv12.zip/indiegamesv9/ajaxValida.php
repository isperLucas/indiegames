<?php
    include_once "classes/conexao.class.php";
    $con = new Conexao();
    
    $email = $_POST['email_cad'];
    $nick = $_POST['nick_cad'];

    try{
        $cst = $con->conectar()->prepare("SELECT email, nick FROM `usuario` WHERE `email` = :email OR `nick` = :nick;");
        $cst->bindParam(":email", $email, PDO::PARAM_INT);
        $cst->bindParam(":nick", $nick, PDO::PARAM_INT);
        $cst->execute();
        
        $rst = $cst->fetch();
        $rst_email = $rst['email'];
        $rst_nick = $rst['nick'];

        if($rst_email == $email){
            $arr[0] = array('error' => '1');
        }else{
            $arr[0] = array('error' => '0');
        }
      
        if($rst_nick == $nick){
            $arr[1] = array('error' => '1');  
        }else{
            $arr[1] = array('error' => '0');  
            
        }
        
        echo json_encode($arr);
        
    } catch (PDOException $ex) {
        return 'erro '.$ex->getMessage();
    }

?>